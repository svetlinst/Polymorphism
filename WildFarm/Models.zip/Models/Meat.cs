﻿namespace WildFarm.Models
{
    using System;
    public class Meat : Food
    {
        public Meat(int quantity) : base(quantity)
        {
        }
    }
}
