﻿namespace WildFarm.Models
{
    using System;
    public class Vegetable : Food
    {
        public Vegetable(int quantity) : base(quantity)
        {
        }
    }
}
